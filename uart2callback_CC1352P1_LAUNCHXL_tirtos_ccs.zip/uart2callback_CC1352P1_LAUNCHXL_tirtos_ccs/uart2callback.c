/*
 * Copyright (c) 2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * DEPENDECY VERSIONS : simplelink_cc13x2_26x2_sdk_5_20_00_52
 *
 * tirtos_builds_cc13x2_cc26x2_release_ccs_5_20_00_52
 */

/*
 *  ======== uart2callback.c ========
 */
#include <stdint.h>
#include <stddef.h>
#include <unistd.h>
#include "string.h"
#include "strings.h"

/* POSIX Header files */
#include <semaphore.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/UART2.h>
//#include "certificates.h"
//#include "awscertification.h"
#include "awscertificates.h"
/* Driver configuration */
#include "ti_drivers_config.h"
#include <ti/display/Display.h> // not required, delete if required


/* **************************************************************
 * UART Handles, Configuration, Variables
 * **************************************************************/

// FREERTOS
static sem_t semUART;
int32_t           semStatus;
uint32_t          status = UART2_STATUS_SUCCESS;

// HANDLES,PARAMS
UART2_Handle      uartDebugHandle,uartSim76xxHandle;
UART2_Params      uartDebugParam,uartSim76xxParam;

// CALLBACKS
void debugTermWriteCallbackFx(UART2_Handle handle, void *buffer, size_t count, // Seems unnecessary delete if required
        void *userArg, int_fast16_t status);
void sim76xxReadCallbackFx(UART2_Handle handle, void *buffer, size_t count,
        void *userArg, int_fast16_t status);

// Debug

// VARIABLES
char              uartDebugRxRingBuff,uartSim76xxRxRingBuff;
char              uartSim76xxRxBuff[1024], uartSim76xxTxBuff[128];
uint16_t          uartSim76xxRxIndex, uartSim76xxTxIndex;
bool              uartSim76xxRxRcvdFlag;
char              uartDebugTxBuff[1024];



// testing variables - delete if needed.
uint8_t volatile txBuff[1024],txvar;
uint8_t volatile RxDone_Flag = 0;
uint8_t volatile   atvar=0;
char  uartSim76xxRxBuff[1024];
char *valuepointer=uartSim76xxRxBuff;
//valuepointer=&uartSim76xxRxBuff;
static volatile size_t numBytesRead;


char AT_check[]="+CMQTTCONNLOST: 0,1";
char *check;
/* DISPLAY Handles, Configuration, Variables */

// testing variables - delete if needed.
//char AT_check[]="OK";
//char *check;
//char AT_check1[]=":";
//char *check1;
//char greater_symbol[]=">";
int i=0,j=1;

uint_fast16_t len_certificate=0;
uint_fast16_t size_certificate=0;

uint_fast16_t topic_length=0;
uint_fast16_t len_privatekey=0;
uint_fast16_t size_privatekey=0;
uint_fast16_t message_legth=0;

uint_fast16_t len_rootcert=0;
uint_fast16_t size_rootcert=0;

/* USER DECLARATION FUNCTION  */
void clear_buffer();

/* **************************************************************
 * MAIN THREAD
 * **************************************************************/

void *mainThread(void *arg0)
{

    // LOCAL VARIABLES

    /* SEMAPHORE INIT*/
    semStatus = sem_init(&semUART, 0, 0); /* Create semaphore */

    if (semStatus != 0) {
        /* Error creating semaphore */
        while (1);
    }

    /* UART INIT */
    // Debug UART
    UART2_Params_init(&uartDebugParam);
    uartDebugParam.readMode = UART2_Mode_BLOCKING; /* Create a UART in CALLBACK read mode */
    uartDebugParam.writeMode = UART2_Mode_BLOCKING;
    //uartDebugParam.readCallback = debugTermWriteCallbackFx;
    uartDebugParam.baudRate = 115200;

    uartDebugHandle = UART2_open(CONFIG_UART2_0, &uartDebugParam);

    if (uartDebugHandle == NULL) {
        while (1);
    }

    UART2_write(uartDebugHandle, "Debug UART Initialized Successfully\r\n", strlen("Debug UART Initialized Successfully\r\n"), NULL);


    // Sim76xx UART
    /* Create a UART in CALLBACK read mode */
    UART2_Params_init(&uartSim76xxParam);
    uartSim76xxParam.readMode = UART2_Mode_CALLBACK;
    uartSim76xxParam.writeMode = UART2_Mode_BLOCKING;
    uartSim76xxParam.readCallback = sim76xxReadCallbackFx;
    uartSim76xxParam.baudRate = 115200;

    uartSim76xxHandle = UART2_open(CONFIG_UART2_1, &uartSim76xxParam);

    if (uartSim76xxHandle == NULL) {
        while (1);
    }
    UART2_write(uartDebugHandle, "Sim76xx UART Initialized Successfully\r\n", strlen("Sim76xx UART Initialized Successfully\r\n"), NULL);


    /* GPIO INIT */
    GPIO_init();  // Call driver init functions
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);  // Configure the LED pin

    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON); /* Turn on user LED to indicate successful initialization */

    UART2_write(uartDebugHandle, "Switching ON GPIO0 \r\n", strlen("Switching ON GPIO0 \r\n"), NULL);

    //unsigned char test_valuec[]={0x41,0x54,0x0D,0x0D,0x0a,0x4F,0x4B,0x0D,0x0a};
    //UART2_write(uartDebugHandle, test_valuec, strlen(test_valuec), NULL);

    UART2_write(uartSim76xxHandle, "AT\r\n", strlen("AT\r\n"), NULL);             // Normal AT check
    status = UART2_read(uartSim76xxHandle, &uartSim76xxRxRingBuff, 1, NULL);
    sem_wait(&semUART);
    sleep(5);
    uint8_t test_len=strlen(uartSim76xxRxBuff);
    UART2_write(uartDebugHandle, uartSim76xxRxBuff, strlen(uartSim76xxRxBuff), NULL);
    sleep(5);
    clear_buffer();


    UART2_write(uartSim76xxHandle, "ATE0\r\n", strlen("ATE0\r\n"), NULL);             // Echo Off
    status = UART2_read(uartSim76xxHandle, &uartSim76xxRxRingBuff, 1, NULL);
    sem_wait(&semUART);
    sleep(2);
    UART2_write(uartDebugHandle, uartSim76xxRxBuff, strlen(uartSim76xxRxBuff), NULL);
    clear_buffer();
    sleep(3);

    UART2_write(uartDebugHandle, "AT+CMEE=1\r\n", strlen("AT+CMEE=1\r\n"), NULL);
    sleep(1);
    UART2_write(uartSim76xxHandle, "AT+CMEE=1\r\n", strlen("AT+CMEE=1\r\n"), NULL); // Check for Error Code
    status = UART2_read(uartSim76xxHandle, &uartSim76xxRxRingBuff, 1, NULL);
    sem_wait(&semUART);
    sleep(2);
    UART2_write(uartDebugHandle, uartSim76xxRxBuff, strlen(uartSim76xxRxBuff), NULL);
    sleep(3);
    clear_buffer();


    UART2_write(uartSim76xxHandle, "AT+CSQ\r\n", strlen("AT+CSQ\r\n"), NULL);
    status = UART2_read(uartSim76xxHandle, &uartDebugRxRingBuff, 1, NULL);                      //Step 2 if responese is 99 then we have to restart the module AT+CREG?
    sem_wait(&semUART);
    sleep(2);
    UART2_write(uartDebugHandle, uartSim76xxRxBuff, strlen(uartSim76xxRxBuff), NULL);
    sleep(3);
    clear_buffer();


    UART2_write(uartSim76xxHandle, "AT+CREG?\r\n", strlen("AT+CREG?\r\n"), NULL);
    status = UART2_read(uartSim76xxHandle, &uartDebugRxRingBuff, 1, NULL);                      //Step 3 Netwwork registartion response should be OK
    sem_wait(&semUART);
    sleep(2);
    UART2_write(uartDebugHandle, uartSim76xxRxBuff, strlen(uartSim76xxRxBuff), NULL);
    sleep(3);
    clear_buffer();

    UART2_write(uartSim76xxHandle, "AT+CGREG?\r\n", strlen("AT+CGREG?\r\n"), NULL);
    status = UART2_read(uartSim76xxHandle, &uartDebugRxRingBuff, 1, NULL);                      //Step 4 GPRS Network registartion response should be OK
    sem_wait(&semUART);
    sleep(2);
    UART2_write(uartDebugHandle, uartSim76xxRxBuff, strlen(uartSim76xxRxBuff), NULL);
    sleep(3);
    clear_buffer();


//    len_certificate=strlen(clientcert_pem);
//    len_privatekey=strlen(PRIVATE_KEY);
//    len_rootcert=strlen(AmazonRootCA1);

    len_certificate=strlen(clientcert1);
        len_privatekey=strlen(clientkey1);
        len_rootcert=strlen(cacert1);

//    size_certificate=sizeof(clientcert_pem);
//    size_privatekey=sizeof(PRIVATE_KEY);
//    size_rootcert=sizeof(AmazonRootCA1);

    topic_length=strlen(topic);
    message_legth=strlen(message);

    /******************************************************* CERTIFICATE **************************************************************************************/

    /******************************  Sending Command for downloading certificate*******************************************************************************/

    UART2_write(uartDebugHandle, "AT+CCERTDOWN=\"clientcert.pem\",1220\r\n", strlen("AT+CCERTDOWN=\"clientcert.pem\",1220\r\n"), NULL);
    sleep(1);
    UART2_write(uartSim76xxHandle, "AT+CCERTDOWN=\"clientcert.pem\",1219\r\n", strlen("AT+CCERTDOWN=\"clientcert.pem\",1219\r\n"), NULL);
    sleep(2);
    status = UART2_read(uartSim76xxHandle, &uartDebugRxRingBuff, 1, NULL);
    sem_wait(&semUART);

    UART2_write(uartDebugHandle, uartSim76xxRxBuff, strlen(uartSim76xxRxBuff), NULL);                              // what is response throw it on debuuger UART
    sleep(2);//string compare for > symbol returns 0 on success
   // UART2_write(uartDebugHandle, clientcert_pem, 1200, NULL);
    clear_buffer();

    /**************************************Sending Command for downloading certificate Ends here now wait for certificate value to download*******************/

    /*************************************Downloading Certificate will starts from below command***********************************************************/

       UART2_write(uartSim76xxHandle,clientcert1,len_certificate,  NULL);              // Now give Certificate to receive ok responce
       status = UART2_read(uartSim76xxHandle, &uartDebugRxRingBuff, 1, NULL);
       sem_wait(&semUART);
       sleep(2);
       UART2_write(uartDebugHandle, uartSim76xxRxBuff, strlen(uartSim76xxRxBuff), NULL);                              // what is response throw it on debuuger UART
       sleep(10);
       clear_buffer();                                                          // Now certificate is downloaded clear AT buffer refresh it for another command response
       sem_wait(&semUART);
     //  sleep(2);
    /*************************************Downloading Certificate is completed ***********************************************************/
    /******************************************************* END CERTIFICATE ***********************************************************/



    /******************************************************* PRIVATE KEY ***********************************************************/
    /******************************  Sending Command for downloading PRIVATE KEY*****************************************************/
       UART2_write(uartDebugHandle, "AT+CCERTDOWN=\"clientkey.pem\",1677\r\n", strlen("AT+CCERTDOWN=\"clientkey.pem\",1677\r\n"), NULL);
       sleep(1);
       UART2_write(uartSim76xxHandle, "AT+CCERTDOWN=\"clientkey.pem\",1678 \r\n", strlen("AT+CCERTDOWN=\"clientkey.pem\",1678 \r\n"), NULL);
       sleep(2);
       status = UART2_read(uartSim76xxHandle, &uartDebugRxRingBuff, 1, NULL);
       sem_wait(&semUART);
       sleep(1);
       UART2_write(uartDebugHandle, uartSim76xxRxBuff, strlen(uartSim76xxRxBuff), NULL);                              // what is response throw it on debuuger UART
      sleep(2);
      clear_buffer();

       sem_wait(&semUART);
       sleep(2);
    /**************************************Sending Command for downloading private key Ends here now wait for key value to download*******************/

    /*************************************Downloading private key will starts from below command***********************************************************/
      UART2_write(uartSim76xxHandle,  clientkey1,  len_privatekey,  NULL);       // Now give private key to receive ok responce
      sleep(2);
      status = UART2_read(uartSim76xxHandle, &uartDebugRxRingBuff, 1, NULL);
      sem_wait(&semUART);
      sleep(3);
      UART2_write(uartDebugHandle, uartSim76xxRxBuff, strlen(uartSim76xxRxBuff), NULL);                      // what is response throw it on debuuger UART
      sem_wait(&semUART);
      sleep(5);
      clear_buffer();

    /*************************************Downloading private key is completed ***********************************************************/
    /******************************************************* END private key ***********************************************************/

      clear_buffer();


    /******************************************************* ROOT Certificate  ***********************************************************/
    /******************************  Sending Command for downloading ROOT Certificate*****************************************************/
       UART2_write(uartDebugHandle, "AT+CCERTDOWN=\"cacert.pem\",1188\r\n", strlen("AT+CCERTDOWN=\"cacert.pem\",1188\r\n"), NULL);
       sleep(1);
       UART2_write(uartSim76xxHandle, "AT+CCERTDOWN=\"cacert.pem\",1187\r\n", strlen("AT+CCERTDOWN=\"cacert.pem\",1187\r\n"), NULL);
       sleep(2);
       status = UART2_read(uartSim76xxHandle, &uartDebugRxRingBuff, 1, NULL);
       sem_wait(&semUART);
       sleep(1);
       UART2_write(uartDebugHandle, uartSim76xxRxBuff,strlen(uartSim76xxRxBuff), NULL);       // what is response throw it on debuuger UART
       sleep(3);
       sem_wait(&semUART);
       clear_buffer();
       //UART2_write(uartDebugHandle, AmazonRootCA1, len_rootcert, NULL);
       //sem_wait(&semUART);

    /**************************************Sending Command for downloading ROOT Certificate Ends here now wait for ROOT Certificate value to download*******************/

    /*************************************Downloading ROOT Certificate will starts from below command*******************************************************************/
       UART2_write(uartSim76xxHandle,  cacert1,  len_rootcert,  NULL);            // Now give Root Certificate to receive ok responce
       sleep(5);
       status = UART2_read(uartSim76xxHandle, &uartDebugRxRingBuff, 1, NULL);
       sem_wait(&semUART);
       sleep(3);
       UART2_write(uartDebugHandle, uartSim76xxRxBuff,strlen(uartSim76xxRxBuff), NULL);                // what is response throw it on debuuger UART
       sem_wait(&semUART);
       sleep(2);
       clear_buffer();

       UART2_write(uartDebugHandle, "ROOT Certificate DOWNLOADED IF OK\r\n", strlen("ROOT Certificate DOWNLOADED IF OK\r\n"), NULL);
       sem_wait(&semUART);
    /*************************************Downloading Certificate is completed ***********************************************************/
    /******************************************************* END ROOT CERTIFICATE ***********************************************************/

      UART2_write(uartDebugHandle, "AT+CCERTLIST\r\n", strlen("AT+CCERTLIST\r\n"), NULL);
      sleep(1);
      UART2_write(uartSim76xxHandle, "AT+CCERTLIST\r\n", strlen("AT+CCERTLIST\r\n"), NULL); // Check for Error Code
      status = UART2_read(uartSim76xxHandle, &uartSim76xxRxRingBuff, 1, NULL);
      sem_wait(&semUART);
      sleep(2);
      UART2_write(uartDebugHandle, uartSim76xxRxBuff, strlen(uartSim76xxRxBuff), NULL);
      sleep(3);
      clear_buffer();


       UART2_write(uartDebugHandle, "AT+CSSLCFG=\"sslversion\",0,4\r\n", strlen("AT+CSSLCFG=\"sslversion\",0,4\r\n"), NULL);
       sem_wait(&semUART);
       UART2_write(uartSim76xxHandle, "AT+CSSLCFG=\"sslversion\",0,4\r\n", strlen("AT+CSSLCFG=\"sslversion\",0,4\r\n"), NULL);
      sleep(1);
      status = UART2_read(uartSim76xxHandle, &uartDebugRxRingBuff, 1, NULL);
      sem_wait(&semUART);
      sleep(2);
      UART2_write(uartDebugHandle, uartSim76xxRxBuff, strlen(uartSim76xxRxBuff), NULL);
      sleep(1);
      clear_buffer();

       UART2_write(uartDebugHandle, "AT+CSSLCFG=\"authmode\"\r\n", strlen("AT+CSSLCFG=\"authmode\"\r\n"), NULL);
       sem_wait(&semUART);
       UART2_write(uartSim76xxHandle, "AT+CSSLCFG=\"authmode\",0,2\r\n", strlen("AT+CSSLCFG=\"authmode\",0,2\r\n"), NULL);
       sleep(1);
       status = UART2_read(uartSim76xxHandle, &uartDebugRxRingBuff, 1, NULL);
       sem_wait(&semUART);
       sleep(2);
       UART2_write(uartDebugHandle, uartSim76xxRxBuff, strlen(uartSim76xxRxBuff), NULL);
       sleep(3);

       clear_buffer();

       UART2_write(uartDebugHandle, "AT+CSSLCFG=\"cacert\",0,\"cacert1.pem\"\r\n", strlen("AT+CSSLCFG=\"cacert\",0,\"cacert1.pem\"\r\n"), NULL);
       sem_wait(&semUART);
       UART2_write(uartSim76xxHandle, "AT+CSSLCFG=\"cacert\",0,\"cacert1.pem\"\r\n", strlen("AT+CSSLCFG=\"cacert\",0,\"cacert1.pem\"\r\n"), NULL);
       sleep(3);
       status = UART2_read(uartSim76xxHandle, &uartDebugRxRingBuff, 1, NULL);
       sem_wait(&semUART);
       UART2_write(uartDebugHandle, uartSim76xxRxBuff, strlen(uartSim76xxRxBuff), NULL);
       sleep(3);
       clear_buffer();


       UART2_write(uartDebugHandle, "AT+CSSLCFG=\"clientcert\",0,\"clientcert1.pem\"\r\n", strlen("AT+CSSLCFG=\"clientcert\",0,\"clientcert1.pem\"\r\n"), NULL);
       sem_wait(&semUART);
       UART2_write(uartSim76xxHandle, "AT+CSSLCFG=\"clientcert\",0,\"clientcert1.pem\"\r\n", strlen("AT+CSSLCFG=\"clientcert\",0,\"clientcert1.pem\"\r\n"), NULL);
       sleep(3);
       status = UART2_read(uartSim76xxHandle, &uartDebugRxRingBuff, 1, NULL);
       sem_wait(&semUART);
       UART2_write(uartDebugHandle, uartSim76xxRxBuff, strlen(uartSim76xxRxBuff), NULL);
       sleep(3);

       clear_buffer();


        UART2_write(uartDebugHandle, "AT+CSSLCFG=\"clientkey\",0,\"clientkey1.pem\"\r\n", strlen("AT+CSSLCFG=\"clientkey\",0,\"clientkey1.pem\"\r\n"), NULL);
        sem_wait(&semUART);
        UART2_write(uartSim76xxHandle, "AT+CSSLCFG=\"clientkey\",0,\"clientkey1.pem\"\r\n", strlen("AT+CSSLCFG=\"clientkey\",0,\"clientkey1.pem\"\r\n"), NULL);
        sleep(3);
        status = UART2_read(uartSim76xxHandle, &uartDebugRxRingBuff, 1, NULL);
        sem_wait(&semUART);
        UART2_write(uartDebugHandle, uartSim76xxRxBuff, strlen(uartSim76xxRxBuff), NULL);
        sleep(3);

        clear_buffer();

        UART2_write(uartDebugHandle, "AT+CMQTTSTART\r\n", strlen("AT+CMQTTSTART\r\n"), NULL);
        sem_wait(&semUART);
        UART2_write(uartSim76xxHandle, "AT+CMQTTSTART\r\n", strlen("AT+CMQTTSTART\r\n"), NULL);
        sleep(10);
        status = UART2_read(uartSim76xxHandle, &uartDebugRxRingBuff, 1, NULL);
        sem_wait(&semUART);
        sleep(5);
        UART2_write(uartDebugHandle, uartSim76xxRxBuff, strlen(uartSim76xxRxBuff), NULL);
        sleep(3);
        clear_buffer();



         //Acquire Client
         UART2_write(uartDebugHandle, "AT+CMQTTACCQ=0,\"evbs_ti_ani\",1\r\n", strlen("AT+CMQTTACCQ=0,\"evbs_ti_ani\",1\r\n"), NULL);
         sem_wait(&semUART);
         UART2_write(uartSim76xxHandle, "AT+CMQTTACCQ=0,\"evbs_ti_ani\",1\r\n", strlen("AT+CMQTTACCQ=0,\"evbs_ti_ani\",1\r\n"), NULL);
         sleep(3);
         status = UART2_read(uartSim76xxHandle, &uartDebugRxRingBuff, 1, NULL);
         sem_wait(&semUART);
         UART2_write(uartDebugHandle, uartSim76xxRxBuff, strlen(uartSim76xxRxBuff), NULL);
         sleep(3);
         sem_wait(&semUART);
         clear_buffer();

           //Set the SSL context
         UART2_write(uartDebugHandle, "AT+CMQTTSSLCFG=0,0\r\n", strlen("AT+CMQTTSSLCFG=0,0\r\n"), NULL);
                  sem_wait(&semUART);
           UART2_write(uartSim76xxHandle, "AT+CMQTTSSLCFG=0,0\r\n", strlen("AT+CMQTTSSLCFG=0,0\r\n"), NULL);
           sleep(2);
          status = UART2_read(uartSim76xxHandle, &uartDebugRxRingBuff, 1, NULL);
          sem_wait(&semUART);
          UART2_write(uartDebugHandle, uartSim76xxRxBuff, strlen(uartSim76xxRxBuff), NULL);
          sleep(3);
          sem_wait(&semUART);
          clear_buffer();


//          //Connect
//         UART2_write(uartDebugHandle, "AT+CMQTTCONNECT=0,\"URL://https://us-east-1.console.aws.amazon.com/iot/home?region=us-east-1#/test:1883\",3600,1\r\n", strlen("AT+CMQTTCONNECT=0,\"URL://https://us-east-1.console.aws.amazon.com/iot/home?region=us-east-1#/test:1883\",3600,1\r\n"), NULL);
//           sem_wait(&semUART);
//           UART2_write(uartSim76xxHandle, "AT+CMQTTCONNECT=0,\"URL://https://us-east-1.console.aws.amazon.com/iot/home?region=us-east-1#/test:1883\",3600,1\r\n", strlen("AT+CMQTTCONNECT=0,\"URL://https://us-east-1.console.aws.amazon.com/iot/home?region=us-east-1#/test:1883\",3600,1\r\n"), NULL);
//           sleep(2);
//           status = UART2_read(uartSim76xxHandle, &uartDebugRxRingBuff, 1, NULL);
//           sem_wait(&semUART);
//           sleep(5);
//           UART2_write(uartDebugHandle, uartSim76xxRxBuff, strlen(uartSim76xxRxBuff), NULL);
//          sleep(1);
//           clear_buffer();
//           sem_wait(&semUART);


  //TOPIC
/************************************************COMMAND TO ACCESS TOPIC**********************************************/
            UART2_write(uartDebugHandle, "AT+CMQTTWILLTOPIC=0,12\r\n", strlen("AT+CMQTTWILLTOPIC=0,12\r\n"), NULL);
             sem_wait(&semUART);
             UART2_write(uartSim76xxHandle, "AT+CMQTTWILLTOPIC=0,12\r\n", strlen("AT+CMQTTWILLTOPIC=0,12\r\n"), NULL);
             sleep(2);
             status = UART2_read(uartSim76xxHandle, &uartDebugRxRingBuff, 1, NULL);
             sleep(2);
             sem_wait(&semUART);
             UART2_write(uartDebugHandle, uartSim76xxRxBuff, strlen(uartSim76xxRxBuff), NULL);
             sem_wait(&semUART);
             clear_buffer();
/**************************************************TOPIC WILL BE SEND FROM BELOW*************************************/

            UART2_write(uartSim76xxHandle,  topic,  topic_length,  NULL);       // Now give private key to receive ok responce
            sleep(1);
            status = UART2_read(uartSim76xxHandle, &uartDebugRxRingBuff, 1, NULL);
            sem_wait(&semUART);
            sleep(5);
            UART2_write(uartDebugHandle, uartSim76xxRxBuff, strlen(uartSim76xxRxBuff), NULL);                      // what is response throw it on debuuger UART
            sem_wait(&semUART);
            sleep(1);
            clear_buffer();


            //TOPIC
        /************************************************COMMAND TO ACCESS TOPIC**********************************************/
                  UART2_write(uartDebugHandle, "AT+CMQTTWILLMSG=0,9,1\r\n", strlen("AT+CMQTTWILLMSG=0,9,1\r\n"), NULL);
                     sem_wait(&semUART);

                     UART2_write(uartSim76xxHandle, "AT+CMQTTWILLMSG=0,9,1\r\n", strlen("AT+CMQTTWILLMSG=0,17,1\r\n"), NULL);
                     sleep(2);
                     status = UART2_read(uartSim76xxHandle, &uartDebugRxRingBuff, 1, NULL);
                     sem_wait(&semUART);
                     sleep(1);
                     UART2_write(uartDebugHandle, uartSim76xxRxBuff, strlen(uartSim76xxRxBuff), NULL);
                     sleep(3);
                    sem_wait(&semUART);
                    clear_buffer();
        /**************************************************TOPIC WILL BE SEND FROM BELOW*************************************/

                    UART2_write(uartSim76xxHandle,  message,  message_legth,  NULL);       // Now give private key to receive ok responce
                    sleep(2);
                    status = UART2_read(uartSim76xxHandle, &uartDebugRxRingBuff, 1, NULL);
                    sem_wait(&semUART);
                    sleep(2);
                    UART2_write(uartDebugHandle, uartSim76xxRxBuff, strlen(uartSim76xxRxBuff), NULL);                      // what is response throw it on debuuger UART
                    sem_wait(&semUART);
                    sleep(10);
                    clear_buffer();


                     UART2_write(uartDebugHandle, "AT+CMQTTCONNECT=0,\"tcp://a2xg0m2ynir6td-ats.iot.us-east-1.amazonaws.com:8883\",60,1\r\n", strlen("AT+CMQTTCONNECT=0,\"tcp://a2xg0m2ynir6td-ats.iot.us-east-1.amazonaws.com:8883\",60,1\r\n"), NULL);
                      sem_wait(&semUART);

                      UART2_write(uartSim76xxHandle, "AT+CMQTTCONNECT=0,\"tcp://a2xg0m2ynir6td-ats.iot.us-east-1.amazonaws.com:8883\",60,1\r\n", strlen("AT+CMQTTCONNECT=0,\"tcp://a2xg0m2ynir6td-ats.iot.us-east-1.amazonaws.com:8883\",60,1\r\n"), NULL);
                      sleep(2);
                      status = UART2_read(uartSim76xxHandle, &uartDebugRxRingBuff, 1, NULL);
                      sem_wait(&semUART);
                      sleep(5);
                      UART2_write(uartDebugHandle, uartSim76xxRxBuff, strlen(uartSim76xxRxBuff), NULL);
                     sleep(1);
                    // clear_buffer();
                      sem_wait(&semUART);



return 0;
}

void debugTermWriteCallbackFx(UART2_Handle handle, void *buffer, size_t count, // Seems unnecessary delete if required
        void *userArg, int_fast16_t status)
{
    txBuff [txvar++] = ((uint8_t*)buffer)[0];
    //UART2_read(handle,buffer,1,NULL);
    sem_post(&semUART);
}


// Sim76xx
void sim76xxReadCallbackFx(UART2_Handle handle, void *buffer, size_t count,
        void *userArg, int_fast16_t status)
{

    if (status == UART2_STATUS_SUCCESS) {

        uartSim76xxRxBuff[uartSim76xxRxIndex++] = ((uint8_t*)buffer)[0];
    }
    UART2_read(handle,buffer,1,NULL);
    sem_post(&semUART);

    uartSim76xxRxRcvdFlag = true;
}


void clear_buffer()
{
    for(i=0;i<1024;i++)
    {
        uartSim76xxRxBuff[i]='\0';
        txBuff[i]='\0';
        uartSim76xxRxBuff[i]='\0';
    }
    uartSim76xxRxIndex=0;
    atvar=0;
    txvar=0;
}
